<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_AKE; SKELETON=S2; KEY=cmd; SINK=B1; VAR=v0068 */
function SINK_B1($command){
    system($command);
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && array_key_exists("name", $f)) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B1($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
