<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_LOCAL_COPY; SKELETON=S1; KEY=cmd; SINK=B2; VAR=v0065 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$f = $_FILES["cmd"] ?? null;
$a = is_array($f) ? $f : [];
$inp = (string)($a["name"] ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B2($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
