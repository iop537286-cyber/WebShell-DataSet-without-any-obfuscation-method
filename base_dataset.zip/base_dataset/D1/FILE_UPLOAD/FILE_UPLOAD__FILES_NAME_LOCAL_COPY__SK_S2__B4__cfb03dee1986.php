<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_LOCAL_COPY; SKELETON=S2; KEY=cmd; SINK=B4; VAR=v0003 */
function SINK_B4($command){
    passthru($command);
}
$f = $_FILES["cmd"] ?? null;
$a = is_array($f) ? $f : [];
$inp = (string)($a["name"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B4($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
