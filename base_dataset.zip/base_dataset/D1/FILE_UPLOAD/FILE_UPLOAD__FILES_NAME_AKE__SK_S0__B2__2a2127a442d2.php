<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_AKE; SKELETON=S0; KEY=cmd; SINK=B2; VAR=v0015 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && array_key_exists("name", $f)) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B2($inp);
echo (string)($out);
?>
