<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_LOCAL_COPY; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0024 */
function SINK_B1($command){
    system($command);
}
$p = $_POST;
$inp = (string)($p["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
