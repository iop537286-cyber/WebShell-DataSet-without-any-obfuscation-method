<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_DIRECT; SKELETON=S1; KEY=cmd; SINK=B1; VAR=v0020 */
function SINK_B1($command){
    system($command);
}
$inp = (string)($_COOKIE["cmd"] ?? "");
$inp = (string)$inp; // no value processing
function run_sink($x){
    return SINK_B1($x);
}
$out = run_sink($inp);
echo (string)($out);
?>
